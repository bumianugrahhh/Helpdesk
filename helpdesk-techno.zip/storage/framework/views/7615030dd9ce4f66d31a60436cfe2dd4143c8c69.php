<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">

    <title>Halaman Login</title>

    <!-- Custom fonts for this template-->
    <link href="<?php echo e(asset('public/asset/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Style -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/asset/css/loginstyle.css')); ?>">
    
    <!-- Favicon-->
    <link rel="shortcut icon" href="<?php echo e(asset('public/asset/img/fajarlogo.jpeg')); ?>">

</head>

<body>
    <div class="main">
        <div class="container a-container" id="a-container">
            <form class="user" id="a-user" method="post" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                <h2 class="form_title title">Selamat Datang, Login!</h2>
                
                <!-- Show Flash_msg -->
                                
                <span class="form_span">Masukkan Username dan Password Anda</span>
                <input class="form_input <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('username')); ?>" name="username" id="username" type="text" placeholder="Username" autofocus="" autocomplete="username" required="">
                       <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                <input class="form_input <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" id="password" type="password" placeholder="Password" required="" autocomplete="current-password">
                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                <button class="form_button button submit" type="submit">LOGIN</button>
            </form></div>
        
        <div class="switch" id="switch-cnt">
            <div class="switch_circle"></div>
            <div class="switch_circle switch_circle--t"></div>
        
            <div class="switch_container" id="switch-c1">
                <h2 class="switch_title title">Hello Friend !</h2>
                <p class="switch_description description">
                    Selamat datang di website kami, Sampaikan keluhan anda tentang pelayanan yang kami berikan melalui 
                    website ini ! Kami akan membantu dengan senang hati.<br><br>
                    Contact us :
                </p>
                <div class="form_icons">
                    <img class="form_icon" src="<?php echo e(asset('public/asset/img/fb1.svg')); ?>" alt="facebook">
                    <img class="form_icon" src="<?php echo e(asset('public/asset/img/linkedin.svg')); ?>" alt="linkedin">
                    <img class="form_icon" src="<?php echo e(asset('public/asset/img/whatsapp.svg')); ?>" alt="whatsapp">
                </div>
            </div>
        </div>
    </div>    
</body>
</html>
<?php /**PATH C:\xampp\htdocs\helpdesk-techno\resources\views/auth/login.blade.php ENDPATH**/ ?>