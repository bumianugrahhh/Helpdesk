 <!-- Bootstrap core JavaScript-->
    <script src="<?php echo e(asset('public/asset/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/asset/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(asset('public/asset/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?php echo e(asset('public/asset/js/sb-admin-2.min.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\helpdesk-techno\resources\views/layouts/script.blade.php ENDPATH**/ ?>