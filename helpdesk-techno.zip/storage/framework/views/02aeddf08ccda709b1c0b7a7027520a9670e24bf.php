<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
<div class="container-fluid">
    <div class="row">
    <?php if(session()->has('error')): ?>
        <div class="alert alert-danger fade show">
        <button type="button" class="close" data-dismiss="alert">
            <span aria-hidden="true">&times;</span>
        </button>
                <?php echo e(Session::get('error')); ?>

        </div>
    <?php endif; ?>
    <?php if(session()->has('success')): ?>
        <div class="alert alert-success fade show">
        <button type="button" class="close" data-dismiss="alert">
            <span aria-hidden="true">&times;</span>
        </button>
                <?php echo e(Session::get('success')); ?>

        </div>
    <?php endif; ?>
      <div class="col-md-3"></div>
        <div class="col-md-6">

            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h4 class="h4 text-primary"><i class="fas fa-user-plus"></i> Tambah Teknisi</h4>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('teknisi.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <input type="text" name="nama" id="nama" class="form-control border-left-warning <?php if(session()->has('error-nama')): ?> is-invalid <?php endif; ?>" value="<?php echo e(old('nama')); ?>" placeholder="Nama teknisi" required="">
                            <div class="invalid-feedback"><?php echo e(Session::get('error-nama')); ?></div>
                        </div>

                        <div class="form-group">
                            <textarea name="alamat" id="alamat" cols="30" rows="1" class="form-control border-left-warning" placeholder="Alamat teknisi" required=""><?php echo e(old('alamat')); ?></textarea>
                            <div class="invalid-feedback"></div>
                        </div>

                        <div class="form-group">
                            <input type="email" name="email" id="email" class="form-control border-left-warning" value="<?php echo e(old('email')); ?>" placeholder="Email teknisi" required="">
                            <div class="invalid-feedback"></div>
                        </div>

                        <div class="form-group">
                            <input type="text" name="kontak" id="kontak" class="form-control border-left-warning" value="<?php echo e(old('kontak')); ?>" placeholder="Masukkan kontak teknisi" required="">
                            <div class="invalid-feedback"></div>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="float-right btn btn-outline-info shadow-sm">Tambah Data</button>
                            <a href="<?php echo e(route('teknisi.index')); ?>" class="float-right btn btn-outline-warning mr-2 shadow-sm"><i class="fa fa-undo"></i> Kembali</a>
                        </div>

                    </form>
                </div>
            </div>

        </div>
        <!-- / .col -->
    </div>
    <!-- / .row -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\helpdesk-techno\resources\views/pages/teknisi/create.blade.php ENDPATH**/ ?>