<!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>&copy; <script>document.write(new Date().getFullYear())</script> Abidah. Universitas Dipa Makassar</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer --><?php /**PATH C:\xampp\htdocs\helpdesk-techno\resources\views/layouts/footer.blade.php ENDPATH**/ ?>