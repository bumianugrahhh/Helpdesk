-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versi server:                 10.4.17-MariaDB - mariadb.org binary distribution
-- OS Server:                    Win64
-- HeidiSQL Versi:               9.1.0.4908
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping database structure for helpdesk_db
CREATE DATABASE IF NOT EXISTS `helpdesk_db` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `helpdesk_db`;


-- Dumping structure for table helpdesk_db.instansi
CREATE TABLE IF NOT EXISTS `instansi` (
  `id_instansi` varchar(70) NOT NULL,
  `nama_instansi` varchar(100) DEFAULT NULL,
  `email` varchar(70) DEFAULT NULL,
  `alamat` varchar(150) DEFAULT NULL,
  `kontak` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_instansi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table helpdesk_db.instansi: ~2 rows (approximately)
DELETE FROM `instansi`;
/*!40000 ALTER TABLE `instansi` DISABLE KEYS */;
INSERT INTO `instansi` (`id_instansi`, `nama_instansi`, `email`, `alamat`, `kontak`, `created_at`, `updated_at`) VALUES
	('5183f720-9017-43e8-9c43-cf7ad1b2cce7', 'PT. Media Fajar Koran', 'mediafajarkoran@gmail.com', 'Lt. 4', '-', '2021-11-01 03:06:52', '2021-11-01 03:06:52'),
	('a93c373e-1849-4f3b-a9b6-9a39846f8e23', 'PT. Fajar Media Pendidikan', 'fajar_pendidikan.mks@yahoo.com', 'Lt. 4', '-', '2021-11-01 02:52:41', '2021-11-01 02:52:41'),
	('b758c5b1-75b1-4405-bc95-cc279ece5dc9', 'PT. Fajar National Network', 'redaksifajaronline@gmail.com', 'Lt. 4', '-', '2021-11-01 03:06:06', '2021-11-01 03:06:06');
/*!40000 ALTER TABLE `instansi` ENABLE KEYS */;


-- Dumping structure for table helpdesk_db.migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table helpdesk_db.migrations: ~2 rows (approximately)
DELETE FROM `migrations`;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2014_10_12_000000_create_users_table', 1),
	(2, '2014_10_12_100000_create_password_resets_table', 1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;


-- Dumping structure for table helpdesk_db.password_resets
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table helpdesk_db.password_resets: ~0 rows (approximately)
DELETE FROM `password_resets`;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;


-- Dumping structure for table helpdesk_db.pengaduan
CREATE TABLE IF NOT EXISTS `pengaduan` (
  `id_pengaduan` varchar(70) NOT NULL,
  `id_instansi` varchar(70) DEFAULT NULL,
  `id_teknisi` varchar(70) DEFAULT NULL,
  `tgl_pengaduan` date DEFAULT NULL,
  `judul_pengaduan` varchar(350) DEFAULT NULL,
  `isi_pengaduan` text DEFAULT NULL,
  `status_pengaduan` enum('Antrian','Proses','Selesai','Batal') DEFAULT 'Antrian',
  `bukti_proses` varchar(70) DEFAULT NULL,
  `bukti_selesai` varchar(70) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_pengaduan`),
  KEY `id_instansi` (`id_instansi`),
  KEY `id_teknisi` (`id_teknisi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table helpdesk_db.pengaduan: ~3 rows (approximately)
DELETE FROM `pengaduan`;
/*!40000 ALTER TABLE `pengaduan` DISABLE KEYS */;
INSERT INTO `pengaduan` (`id_pengaduan`, `id_instansi`, `id_teknisi`, `tgl_pengaduan`, `judul_pengaduan`, `isi_pengaduan`, `status_pengaduan`, `bukti_proses`, `bukti_selesai`, `created_at`, `updated_at`) VALUES
	('1f572354-5d09-4282-9f4c-39723e8890a7', '5183f720-9017-43e8-9c43-cf7ad1b2cce7', '064fbe51-8afa-47f8-9eb4-5acc0d8dc6b2', '2021-11-01', 'Pengaduan 2', 'Tes pengiriman pengaduan ke sistem', 'Selesai', '22f7b004-caac-4ac2-bf72-2ddaa3cc3372.jpg', 'bf9a108d-79eb-4c0e-8c9c-d19a0fd4a265.jpg', '2021-11-01 07:16:58', '2021-11-01 09:43:09'),
	('3c59f9c9-db4f-4d2c-bc72-403f2da14e46', 'a93c373e-1849-4f3b-a9b6-9a39846f8e23', 'b7ab7a80-2af6-49d1-a20a-13ca68697d44', '2021-11-01', 'Jaringan Lambat', 'Jaringan sangat lambat apabila sudah memasukan jam kerja.', 'Selesai', '041c0e0d-6504-4ff0-8c8a-02ba90187376.jpg', 'bc7e2209-a6ae-4d7d-b8d1-70c47ce1d18a.jpg', '2021-11-01 06:58:20', '2021-11-01 10:28:19'),
	('ef13fcf2-cda9-411e-9661-cfa10501c4aa', '5183f720-9017-43e8-9c43-cf7ad1b2cce7', NULL, '2021-11-01', 'Pengaduan 3', 'Isi teks pengaduan ke 3', 'Antrian', NULL, NULL, '2021-11-01 10:03:30', '2021-11-01 10:03:30');
/*!40000 ALTER TABLE `pengaduan` ENABLE KEYS */;


-- Dumping structure for table helpdesk_db.teknisi
CREATE TABLE IF NOT EXISTS `teknisi` (
  `id_teknisi` varchar(70) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `alamat` varchar(150) DEFAULT NULL,
  `kontak` varchar(50) DEFAULT NULL,
  `email` varchar(70) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_teknisi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table helpdesk_db.teknisi: ~2 rows (approximately)
DELETE FROM `teknisi`;
/*!40000 ALTER TABLE `teknisi` DISABLE KEYS */;
INSERT INTO `teknisi` (`id_teknisi`, `nama`, `alamat`, `kontak`, `email`, `created_at`, `updated_at`) VALUES
	('064fbe51-8afa-47f8-9eb4-5acc0d8dc6b2', 'Asdar', '-', '083344556677', 'asdar@yahoo.com', '2021-11-01 05:11:15', '2021-11-01 05:11:15'),
	('4285dbe3-c532-4e37-8840-fd60e2852e3a', 'Ardi', '-', '082233445566', 'ardi@gmail.com', '2021-11-01 05:10:53', '2021-11-01 05:10:53'),
	('b7ab7a80-2af6-49d1-a20a-13ca68697d44', 'Muh. Gazali Muchtar', '-', '081122334455', 'gazalimuchtar@gmail.com', '2021-11-01 05:10:32', '2021-11-01 05:10:32');
/*!40000 ALTER TABLE `teknisi` ENABLE KEYS */;


-- Dumping structure for table helpdesk_db.users
CREATE TABLE IF NOT EXISTS `users` (
  `id_user` varchar(70) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_instansi` varchar(70) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(35) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipe` enum('ADMIN','USER') COLLATE utf8mb4_unicode_ci DEFAULT 'USER',
  `foto` varchar(70) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_user`),
  KEY `id_instansi` (`id_instansi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table helpdesk_db.users: ~4 rows (approximately)
DELETE FROM `users`;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id_user`, `id_instansi`, `username`, `password`, `tipe`, `foto`, `created_at`, `updated_at`) VALUES
	('17ae1c0e-a2ca-44ab-a6cd-7bf994b975aa', '5183f720-9017-43e8-9c43-cf7ad1b2cce7', 'mediafajarkoran', '$2y$10$dec5yU2Ch6PvRk203holEeIySN9U5FFwzOI0GmdKufQeuNyLlsstW', 'USER', NULL, '2021-11-01 03:06:52', '2021-11-01 03:06:52'),
	('5780b775-55dd-446c-bf5a-3ea0e06d99d0', 'a93c373e-1849-4f3b-a9b6-9a39846f8e23', 'fajarmpendidikan', '$2y$10$qmQA9x5CHkcyRmPcbQVuueK5XleyOpp8U3rN3YGz3Fbbx/E1TwESq', 'USER', NULL, '2021-11-01 02:52:41', '2021-11-01 02:52:41'),
	('945fd0c9-cb65-4740-8b6c-fe838603a7d9', NULL, 'admin123', '$2y$10$0DT4HVBChk7JlHWkYbSTEupvUe/3eLy9SIUuReA7YsLeVbyzomv/2', 'ADMIN', 'e38c82cc-0154-411a-9d3c-e1e4b73cc20f.jpg', '2021-11-01 01:53:48', '2021-11-01 05:52:38'),
	('d07d7e41-1cff-4069-b038-d5fd0a735553', 'b758c5b1-75b1-4405-bc95-cc279ece5dc9', 'fnnmakassar', '$2y$10$naO5JorErCFl3ejwZvtl1eBf8mGa0G1cZRBhFs4ozAKsA8ydud/BS', 'USER', NULL, '2021-11-01 03:06:07', '2021-11-01 03:06:07');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
